About
=====

.. toctree::
   :maxdepth: 1
   :caption: Contents

   features
   release-information
   maintainers
   contact
   acknowledgements
